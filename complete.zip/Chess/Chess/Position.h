#pragma once
//***************************
// The location in the board
//***************************
struct Position {
	int x;
	int y;
};